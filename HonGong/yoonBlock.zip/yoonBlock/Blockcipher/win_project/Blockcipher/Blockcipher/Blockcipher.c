#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "edge_crypto.h"

int bin2hex(const unsigned char *in_bin, int bin_len, char *out_hex);

int main() {
	
}

//bindata -> hex func
int bin2hex(const unsigned char *in_bin, int bin_len, char *out_hex) {
	int i;
	char *hexstr = "0123456789ABCDEF";

	if (in_bin == NULL || bin_len == 0) return 0;

	for (i = 0; i < bin_len; i++) {
		out_hex[i * 2] = hexstr[in_bin[i] >> 4];
		out_hex[i * 2 + 1] = hexstr[in_bin[i] & 0x0F];
	}
	out_hex[bin_len * 2] = '\0';

	return 1;
}

//enc block setting 
int cbc_enc_block(int p_algorithmid, uint8_t *p_key, uint32_t p_keyLen, uint8_t *p_in,uint32_t *p_inlen, uint8_t *p_out, uint32_t *p_outlen)
{
	int res = 0, outLen;
	EDGE_CIPHER_PARAMETERS param;
	EDGE_CIPHER_MODE_PARAMETERS* mode_parameters = NULL;

	memset(&param, 0, sizeof(EDGE_CIPHER_PARAMETERS));

	param.m_mode = EDGE_CIPHER_MODE_CBC;
	param.m_padding = EDGE_CIPHER_PADDING_PKCS5;
	mode_parameters = &param.m_modeparam;
	mode_parameters->m_iv;
	mode_parameters->m_ivlength = 16;
	mode_parameters->m_modesize = 0;

	return edge_enc(p_algorithmid, p_key, p_keyLen, &param, p_in, 16, p_out, &outLen);
}

//dec block setting
int cbc_dec_block(int p_algorithmid, uint8_t p_key, uint32_t p_keyLen, uint8_t *p_in, uint32_t *p_inlen, uint8_t *p_out, uint32_t *p_outlen) {

	int res = 0, outlen;
	EDGE_CIPHER_PARAMETERS param;
	EDGE_CIPHER_MODE_PARAMETERS* mode_parameters = NULL;

	param.m_mode = EDGE_CIPHER_MODE_CBC;
	param.m_padding = EDGE_CIPHER_PADDING_PKCS5;
	mode_parameters = &param.m_modeparam;



	return edge_dec(p_algorithmid, p_key, p_keyLen, &param,)
}